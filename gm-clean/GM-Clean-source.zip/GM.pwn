#include <a_samp>

#define GM_NAME                 "Urbano RP - Base limpa"
#define DIALOG_LOGIN            (4100)
#define DIALOG_REGISTER         (4101)
#define DIALOG_INFO             (4102)

#define AUTH_NONE               (0)
#define AUTH_DIALOG             (1)
#define AUTH_OK                 (2)

#define SPAWN_X                 (1481.0)
#define SPAWN_Y                 (-1771.0)
#define SPAWN_Z                 (18.8)
#define SPAWN_ANGLE             (0.0)
#define SPAWN_SKIN              (0)

new gAuthState[MAX_PLAYERS];
new gDialogOpen[MAX_PLAYERS];
new gAccountPath[MAX_PLAYERS][48];

forward SafeRespawn(playerid);
forward OpenAuthDialogDelayed(playerid);
stock ShowAuthenticationDialog(playerid);

public OpenAuthDialogDelayed(playerid)
{
    if (!IsPlayerConnected(playerid) || gAuthState[playerid] == AUTH_OK)
        return 1;
    if (gDialogOpen[playerid])
        return 1;

    printf("[URBANO-BASE] delayed auth dialog for player %d", playerid);
    return ShowAuthenticationDialog(playerid);
}

public OnGameModeInit()
{
    SetGameModeText(GM_NAME);
    ShowPlayerMarkers(PLAYER_MARKERS_MODE_OFF);
    ShowNameTags(true);
    SetNameTagDrawDistance(30.0);
    UsePlayerPedAnims();

    // At least one real class is intentional: the diagnostic showed the client
    // receiving spawnsAvailable=0, which can prevent RequestClass/login startup.
    AddPlayerClass(SPAWN_SKIN, SPAWN_X, SPAWN_Y, SPAWN_Z, SPAWN_ANGLE,
        0, 0, 0, 0, 0, 0);
    AddPlayerClass(7, SPAWN_X, SPAWN_Y, SPAWN_Z, SPAWN_ANGLE,
        0, 0, 0, 0, 0, 0);
    AddPlayerClass(14, SPAWN_X, SPAWN_Y, SPAWN_Z, SPAWN_ANGLE,
        0, 0, 0, 0, 0, 0);

    print("[URBANO-BASE] Clean login/spawn gamemode initialized.");
    return 1;
}

public OnGameModeExit()
{
    print("[URBANO-BASE] Gamemode stopped.");
    return 1;
}

public OnPlayerConnect(playerid)
{
    gAuthState[playerid] = AUTH_NONE;
    gDialogOpen[playerid] = 0;
    GetAccountPath(playerid, gAccountPath[playerid], sizeof(gAccountPath[]));
    SendClientMessage(playerid, 0x78C8FFFF,
        "Urbano RP: conectando. O login/cadastro vai abrir automaticamente.");
    printf("[URBANO-BASE] player %d connected; scheduling auth dialog", playerid);
    SetTimerEx("OpenAuthDialogDelayed", 1500, false, "i", playerid);
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    #pragma unused reason
    gAuthState[playerid] = AUTH_NONE;
    gDialogOpen[playerid] = 0;
    gAccountPath[playerid][0] = EOS;
    return 1;
}

public OnPlayerRequestClass(playerid, classid)
{
    #pragma unused classid
    printf("[URBANO-BASE] OnPlayerRequestClass for player %d", playerid);
    if (gAuthState[playerid] == AUTH_OK) return 1;
    if (!gDialogOpen[playerid])
        ShowAuthenticationDialog(playerid);
    return 1;
}

stock GetAccountPath(playerid, path[], pathSize)
{
    new playerName[MAX_PLAYER_NAME + 1];
    GetPlayerName(playerid, playerName, sizeof(playerName));

    // SA-MP nicknames are alphanumeric/underscore. Reject anything else before
    // using the nick in a filename, even if a nonstandard client bypasses this.
    for (new i = 0; playerName[i] != EOS; i++)
    {
        if (!((playerName[i] >= 'a' && playerName[i] <= 'z') ||
              (playerName[i] >= 'A' && playerName[i] <= 'Z') ||
              (playerName[i] >= '0' && playerName[i] <= '9') ||
              playerName[i] == '_'))
        {
            format(path, pathSize, "");
            return 0;
        }
    }
    format(path, pathSize, "urbano_%s.pass", playerName);
    return 1;
}

stock ShowAuthenticationDialog(playerid)
{
    if (gAuthState[playerid] == AUTH_OK) return 1;

    if (gAccountPath[playerid][0] == EOS &&
        !GetAccountPath(playerid, gAccountPath[playerid], sizeof(gAccountPath[])))
    {
        SendClientMessage(playerid, 0xFF7777FF,
            "Seu nick so pode ter letras, numeros e underline (_). Reconecte com um nick valido.");
        Kick(playerid);
        return 1;
    }

    gAuthState[playerid] = AUTH_DIALOG;
    gDialogOpen[playerid] = 1;
    if (fexist(gAccountPath[playerid]))
    {
        ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD,
            "Urbano RP - Login", "Digite a senha da sua conta para continuar.",
            "Entrar", "Sair");
    }
    else
    {
        ShowPlayerDialog(playerid, DIALOG_REGISTER, DIALOG_STYLE_PASSWORD,
            "Urbano RP - Cadastro", "Crie uma senha de 6 a 32 caracteres.\nEla sera salva como hash SHA-256.",
            "Criar", "Sair");
    }
    return 1;
}

stock AuthenticateAndSpawn(playerid)
{
    gAuthState[playerid] = AUTH_OK;
    gDialogOpen[playerid] = 0;

    SetSpawnInfo(playerid, NO_TEAM, SPAWN_SKIN,
        SPAWN_X, SPAWN_Y, SPAWN_Z, SPAWN_ANGLE,
        0, 0, 0, 0, 0, 0);

    printf("[URBANO-BASE] player %d authenticated; calling SpawnPlayer", playerid);
    SpawnPlayer(playerid);
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    #pragma unused listitem
    if (dialogid == DIALOG_LOGIN || dialogid == DIALOG_REGISTER)
        printf("[URBANO-BASE] auth dialog response from player %d; dialog=%d accepted=%d", playerid, dialogid, response);
    if (dialogid == DIALOG_INFO)
        return 1;

    if (dialogid != DIALOG_LOGIN && dialogid != DIALOG_REGISTER)
        return 0;

    gDialogOpen[playerid] = 0;
    if (!response)
    {
        Kick(playerid);
        return 1;
    }

    new passwordLength = strlen(inputtext);
    if (passwordLength < 6 || passwordLength > 32)
    {
        SendClientMessage(playerid, 0xFF7777FF,
            "A senha precisa ter de 6 a 32 caracteres.");
        return ShowAuthenticationDialog(playerid);
    }

    new playerName[MAX_PLAYER_NAME + 1];
    new passwordHash[65];
    GetPlayerName(playerid, playerName, sizeof(playerName));
    SHA256_PassHash(inputtext, playerName, passwordHash, sizeof(passwordHash));

    if (dialogid == DIALOG_REGISTER)
    {
        if (fexist(gAccountPath[playerid]))
        {
            SendClientMessage(playerid, 0xFF7777FF,
                "Essa conta ja existe. Faca login.");
            return ShowAuthenticationDialog(playerid);
        }

        new File:accountFile = fopen(gAccountPath[playerid], io_write);
        if (accountFile == File:0)
        {
            SendClientMessage(playerid, 0xFF7777FF,
                "Nao foi possivel criar sua conta. Avise a administracao.");
            return ShowAuthenticationDialog(playerid);
        }
        fwrite(accountFile, passwordHash);
        fclose(accountFile);
        SendClientMessage(playerid, 0x78C8FFFF,
            "Conta criada. Entrando no servidor...");
        return AuthenticateAndSpawn(playerid);
    }

    if (!fexist(gAccountPath[playerid]))
    {
        SendClientMessage(playerid, 0xFF7777FF,
            "Conta nao encontrada. Faca seu cadastro.");
        return ShowAuthenticationDialog(playerid);
    }

    new File:accountFile = fopen(gAccountPath[playerid], io_read);
    if (accountFile == File:0)
    {
        SendClientMessage(playerid, 0xFF7777FF,
            "Nao foi possivel ler sua conta. Tente novamente.");
        return ShowAuthenticationDialog(playerid);
    }

    new storedHash[80];
    fread(accountFile, storedHash, sizeof(storedHash), false);
    fclose(accountFile);

    // Be tolerant of line endings if a text editor added one to the account file.
    for (new i = 0; storedHash[i] != EOS; i++)
    {
        if (storedHash[i] == '\r' || storedHash[i] == '\n')
        {
            storedHash[i] = EOS;
            break;
        }
    }

    if (strcmp(passwordHash, storedHash, false) != 0)
    {
        SendClientMessage(playerid, 0xFF7777FF,
            "Senha incorreta.");
        return ShowAuthenticationDialog(playerid);
    }

    SendClientMessage(playerid, 0x78C8FFFF,
        "Login confirmado. Entrando no servidor...");
    return AuthenticateAndSpawn(playerid);
}

public OnPlayerSpawn(playerid)
{
    if (gAuthState[playerid] != AUTH_OK)
    {
        SendClientMessage(playerid, 0xFF7777FF,
            "Faca login antes de entrar no jogo.");
        Kick(playerid);
        return 1;
    }

    SetPlayerHealth(playerid, 100.0);
    SetPlayerArmour(playerid, 0.0);
    SetPlayerInterior(playerid, 0);
    SetPlayerVirtualWorld(playerid, 0);
    SetCameraBehindPlayer(playerid);
    TogglePlayerControllable(playerid, true);
    SendClientMessage(playerid, 0x78C8FFFF,
        "Voce entrou no Urbano RP. Use /ajuda para ver os comandos basicos.");
    printf("[URBANO-BASE] OnPlayerSpawn success for player %d", playerid);
    return 1;
}

public OnPlayerDeath(playerid, killerid, reason)
{
    #pragma unused killerid, reason
    if (gAuthState[playerid] == AUTH_OK)
        SetTimerEx("SafeRespawn", 2500, false, "i", playerid);
    return 1;
}

public SafeRespawn(playerid)
{
    if (IsPlayerConnected(playerid) && gAuthState[playerid] == AUTH_OK)
    {
        SetSpawnInfo(playerid, NO_TEAM, SPAWN_SKIN,
            SPAWN_X, SPAWN_Y, SPAWN_Z, SPAWN_ANGLE,
            0, 0, 0, 0, 0, 0);
        SpawnPlayer(playerid);
    }
    return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
    if (!strcmp(cmdtext, "/login", true) && gAuthState[playerid] != AUTH_OK)
    {
        printf("[URBANO-BASE] /login requested by player %d", playerid);
        gDialogOpen[playerid] = 0;
        ShowAuthenticationDialog(playerid);
        return 1;
    }

    if (gAuthState[playerid] != AUTH_OK)
    {
        SendClientMessage(playerid, 0xFF7777FF,
            "Faca login antes de usar comandos.");
        return 1;
    }

    if (!strcmp(cmdtext, "/ajuda", true))
    {
        SendClientMessage(playerid, 0x78C8FFFF,
            "Comandos da base: /ajuda, /spawn e /sair.");
        return 1;
    }
    if (!strcmp(cmdtext, "/spawn", true))
    {
        SetPlayerInterior(playerid, 0);
        SetPlayerVirtualWorld(playerid, 0);
        SetPlayerPos(playerid, SPAWN_X, SPAWN_Y, SPAWN_Z);
        SetPlayerFacingAngle(playerid, SPAWN_ANGLE);
        SetCameraBehindPlayer(playerid);
        SendClientMessage(playerid, 0x78C8FFFF,
            "Voce voltou ao ponto inicial.");
        return 1;
    }
    if (!strcmp(cmdtext, "/sair", true))
    {
        Kick(playerid);
        return 1;
    }
    SendClientMessage(playerid, 0xFF7777FF,
        "Comando desconhecido. Use /ajuda.");
    return 1;
}
