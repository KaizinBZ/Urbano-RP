URBANO RP — BASE LIMPA DE LOGIN E SPAWN

Esta e uma gamemode nova, independente da GM Imperio City. O escopo e deliberadamente pequeno para testar uma entrada SA-MP padrao: classes declaradas, dialogo nativo de cadastro/login, hash de senha via SHA256_PassHash, SpawnPlayer, respawn apos morte e comandos /ajuda, /spawn e /sair.

NAO e uma GM de roleplay completa: nao inclui faccoes, empregos, economia, carros, mapa customizado, inventario ou sistemas da GM antiga. Nao substitua a GM atual sem testar primeiro.

ARQUIVOS
- GM.pwn: source da base.
- include/: includes oficiais contidos no pacote da GM que o usuario enviou; utilizados somente para compilacao.

COMPILACAO
Compile GM.pwn com o Pawn compiler compatível com a versao do servidor e a pasta include/. O .amx resultante precisa ser colocado no diretório gamemodes do servidor. A GM cria arquivos `urbano_<nick>.pass` no diretório scriptfiles para as contas.

PORTA E CONFIGURACAO
O pacote nao modifica server.cfg nem define porta. Use a porta/protocolo ja configurados no servidor. Mantenha backup de server.cfg, plugins, filterscripts e scriptfiles. Nao distribua server.cfg com senha RCON.

SEGURANCA/COMPATIBILIDADE
As senhas sao armazenadas como hash com salt igual ao nickname; o hash nao e reversivel, mas a seguranca final depende da implementacao SHA256_PassHash do servidor. Compile e teste no mesmo servidor/versao de SA-MP ou fork. O pacote ainda precisa de teste real no servidor antes de ser tratado como pronto para producao.
